/*! \file
 *  \brief Constants for ATMega644 and custom evaluation board.
 *
 *  Defines several useful constants for the ATMega644 and our AVR evaluation
 *  board.
 *
 *  \author Lehrstuhl Informatik 11 - RWTH Aachen
 */

#ifndef _ATMEGA644CONSTANTS_H
#define _ATMEGA644CONSTANTS_H

//! Clock frequency on evaluation board in HZ (20 MHZ)
#define AVR_CLOCK_FREQUENCY 20000000

//! Clock frequency for WinAVR delay function
#ifndef F_CPU
#define F_CPU 20000000UL
#endif

#endif
